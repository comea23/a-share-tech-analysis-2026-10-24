# pit-backtest

无未来函数（point-in-time）回测引擎 skill（用户级，agent_created）。

## 文件清单

```
pit-backtest/
├── SKILL.md                          # 技能说明（三重保证/工作流/评估口径）
├── README.md                         # 本文件（变更记录）
├── scripts/
│   ├── pit_backtest.py               # 回测主引擎（截断重算+硬校验+评估+策略模拟）
│   ├── enhance_backtest.py           # 分阶段统计+重点检查点对照
│   ├── build_backtest_report.py      # HTML 报告生成
│   ├── indicators.py                 # 指标计算（a-share-tech-indicators 同源副本）
│   └── judge.py                      # 信号规则（同源副本）
└── references/
    └── no-lookahead.md               # 方法论+3起已发事故记录
```

## 变更记录

### v1.0（2026-10-24）
- 初版。从「PIT回测与多周期验证」项目（outputs/）沉淀。
- 相对项目版的修复：
  1. FILES 映射改为 fetch_kline 命名（hs300_k101.json）
  2. load() 兼容空 amount/pct 字段（腾讯源无这两列）
  3. DATA_DIR 环境变量支持（默认脚本所在目录）
- 已修复事故（详见 references/no-lookahead.md）：
  - 前向重叠窗口（ret20）当单日收益复利 → 增加 ret1，策略用真实单日收益
  - 信号当日生效 → T 日信号 T+1 持仓生效，单边成本 0.05%
- 端到端验证：hs300 242 检查点，无未来函数硬校验 8/8 PASS（max_rel=0），
  与项目版结果完全一致（规则A -6.32% / 规则B -7.80% vs 持有 -10.88%）。

## 同步说明

`indicators.py` / `judge.py` 与 a-share-tech-indicators 同源。修改必须同步两处。
