---
name: pit-backtest
description: 无未来函数（point-in-time）回测引擎。当需要验证技术指标/信号规则的历史有效性、「给定一个历史时间点、只能用该时点之前的数据判断后续走势」、或对任何量化规则做时序回测时使用。含截断重算机制、无未来函数硬校验、两套规则（三维投票/多因子评分）对比、策略模拟与 HTML 报告生成。
agent_created: true
---

# 无未来函数回测（PIT Backtest）

## 用途

回答一类问题：「如果站在历史时间点 T、只掌握 T 及之前的数据，规则会给出什么判断？T 之后的实际走势如何？」——以此验证规则有效性，并暴露未来函数缺陷。

## 触发场景

- 「回测这个指标/信号策略在过去一年的表现」
- 「验证某规则是否有效（无未来函数）」
- 「给定时间点只能用之前的数据，分析后续走势」
- 对任何量化判断规则做事后检验

## 无未来函数三重保证（本 skill 的核心）

1. **结构保证**：每个检查点 T 从原始行情重新截断 `df[df.index <= T]` 后**重算**全部指标，不引用全量预计算表；T 日信号次一日起生效
2. **算法保证**：指标全部为因果运算（rolling/ewm/shift 只回看，KDJ 为逐步递推）
3. **硬校验**：抽样检查点对比「截断重算」与「全量计算」在当日的值，逐列断言一致（容差 1e-6 相对误差），校验不过则中止

前向收益（ret5/10/20）仅在评估阶段从事后数据提取，不参与任何判断。

## 工作流

1. 准备数据（东财 klines 格式，命名 `hs300_k101.json` 等，可用 a-share-tech-indicators 的 fetch_kline.py）
2. 运行回测：
   ```bash
   DATA_DIR=<数据目录> python scripts/pit_backtest.py --symbol all --win-start 2025-10-24 --win-end 2026-10-23
   ```
   输出 `backtest_result.json`（逐检查点记录 + 评估 + 策略模拟 + 校验证据）
3. 二次加工（分阶段统计 + 重点检查点对照）：
   ```bash
   DATA_DIR=<数据目录> python scripts/enhance_backtest.py
   ```
   输出 `backtest_enhanced.json`
4. 生成报告：`DATA_DIR=<数据目录> python scripts/build_backtest_report.py` → `PIT回测与多周期验证报告.html`

## 评估口径

- **方向胜率**：仅统计有方向信号（多/空），中性单列「平均绝对收益」（验证「不轻易出手」本身是有效信号）
- **策略模拟**：T 日信号 → T+1 持仓生效；+1 满仓 / -1 空仓 / 0 维持；单边成本 0.05%
- **日收益必须用真实单日收益**，严禁用前向重叠窗口（ret20）复利——见 references/no-lookahead.md 事故记录

## 已验证结论（2026-10-24）

- 沪深300：规则A 策略 -6.32% vs 持有 -10.88%（超额 +4.55%，回撤 -7.28% vs -20.27%）
- 科创50：规则B 策略 +19.93% vs 持有 -3.91%（超额 +23.84%）
- 超额收益全部来自回避主跌段，方向胜率并不高；规则A 做空信号在沪深300 胜率 0%
- 单窗口样本内验证，投入实盘前应在第二个市场/时段重复验证

## Resources

### scripts/
- `pit_backtest.py`：回测主引擎（截断重算 + 硬校验 + 评估 + 策略模拟）
- `enhance_backtest.py`：分阶段统计 + 重点检查点对照
- `build_backtest_report.py`：HTML 报告生成
- `indicators.py` / `judge.py`：指标与规则（与 a-share-tech-indicators 同源副本，修改需同步两处）

### references/
- `no-lookahead.md`：无未来函数方法论与已发事故记录（重叠前向收益、位置索引错位、T+1 时序）
