---
name: a-share-tech-indicators
description: A股指数/ETF/个股的技术指标分析与技术面报告生成。当需要计算或解读 MACD、KDJ、RSI、BOLL、均线、OBV、ADX、ATR 等技术指标，生成指数/标的技术面研究报告，或获取 A 股行情数据（日K/60分钟/5分钟/资金流）时使用。含多源容错数据获取、纯因果指标计算、两套信号规则（三维投票引擎 + 多因子评分）。
agent_created: true
---

# A股技术指标分析

## 用途

对 A 股指数/ETF/个股做完整技术面分析：行情获取 → 指标计算 → 信号判断 → HTML 报告。
所有指标计算为纯因果实现（rolling/ewm 只回看），可安全用于 point-in-time 场景。

## 触发场景

- 「分析 XX 指数/股票近一年的 MACD/KDJ/RSI/BOLL 等技术指标」
- 「生成 XX 的技术面研究报告」
- 「获取 A 股日K/小时K/分钟K/资金流数据」
- 为回测（pit-backtest）或国家队分析（national-team-flow）准备数据

## 工作流

1. **获取数据**：`python scripts/fetch_kline.py --symbols hs300,kc50 --klt 101 --start 20240901 --end 20261024 --outdir <数据目录>`
   - 支持代码：hs300 / kc50 / zz500 / zz1000 / cyb / 510300 / 510330 / 510310 / 159919
   - 周期：101=日K，60/30/15/5=分钟K；`--fflow` 附加指数资金流（仅东财，约120日）
   - 输出统一为东财 klines 字符串格式：`date,open,close,high,low,volume,amount,pct`
2. **计算指标**：`from indicators import compute_all; ind = compute_all(df)`（df 需 open/high/low/close/volume 列）
3. **形成判断**：`from judge import rule_a_engine, rule_b_score`
   - 规则A：三维投票（趋势 EMA12/26+ADX25 / 均值回归 BB+RSI14 / 量价 OBV），输出 +1/0/-1
   - 规则B：多因子评分（趋势40/动量30/波动10/量价20+偏离修正），输出 (direction, score, reasons)
4. **生成报告**：遵循金融场景报告规范（浅底深字、ECharts CDN、红涨绿跌、图/表可切换、指标状态总表+信号事件表+情景推演），必须附免责声明

## 数据陷阱（必读）

详见 `references/data-sources.md`。最关键三条：
- 东财 push2his 分钟接口（klt=60/5）在部分网络下返回 HTTP 000，**直接降级腾讯/新浪，不要反复重试**
- 腾讯 fqkline 日期必须带连字符（2025-01-01），东财必须不带（20250101）
- 所有源 volume 单位=手，成交额 = volume × 100 × close（指数 volume 为股，不乘）

## 指标清单

MA(5/10/20/60/120/250)、MACD(12,26,9)、RSI(6/12/24, Wilder)、KDJ(9,3,3)、
BOLL(20,2)、OBV(20)、ADX(14)、ATR(14)、量比(5)。

## 已验证结论（2026-10-24，沪深300/科创50 近一年）

- 两套规则在熊市中的价值是风控（回避主跌段）而非抄底；做空信号严重滞后（沪深300 胜率 0%）
- 中期反转确认三条件：站上 MA20 + MACD 零轴金叉红柱放大 + 量能持续放大
- 60 分钟 MACD 金叉中位提前日线约 20 天，但方向胜率无优势——小时线定位为提前预警，日线定方向

## 环境备注

- 依赖 pandas/numpy；受管 venv 安装 pandas 超时时可回退系统 Python（需自带 pandas）
- 数据目录通过环境变量 `DATA_DIR` 指定（默认脚本所在目录）

## Resources

### scripts/
- `fetch_kline.py`：多源容错数据获取（东财主源，腾讯/新浪备选）
- `indicators.py`：纯因果指标计算（compute_all）
- `judge.py`：两套信号规则（rule_a_engine / rule_b_score）

### references/
- `data-sources.md`：数据接口清单、字段口径、单位陷阱、故障处置
