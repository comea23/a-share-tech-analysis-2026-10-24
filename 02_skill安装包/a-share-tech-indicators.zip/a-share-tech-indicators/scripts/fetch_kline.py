# -*- coding: utf-8 -*-
"""A股K线数据获取（多源容错）。

主源：东方财富 push2his（日K、指数资金流）
备选：腾讯 ifzq.gtimg.cn（日K、分钟K）、新浪 quotes.sina.cn（5/15/30/60分钟K）

2026-10-24 实测陷阱（选源与排障必读）：
1. 东财 push2his.eastmoney.com 的 klt=60/5 分钟接口在部分网络下返回 HTTP 000
   （连接重置，root 路径却返回 404），换节点（33/50/90...）同样失败——直接降级
   腾讯 mkline 或新浪分钟接口，不要反复重试东财。
2. 东财 kline 的 beg/end 对分钟级可能被忽略；分钟线用 end=20500101&lmt=N。
3. 东财 fflow（资金流）daykline 只返回最近约 120 个交易日，beg 参数无效。
4. 腾讯 fqkline 字段顺序为 [date, open, close, high, low, volume]，volume 单位=手；
   东财 kline 字段为 [date, open, close, high, low, volume, amount, ...]，volume 单位=手。
   计算成交额必须 volume*100*close（指数 volume 单位为股，不需要乘）。
5. 新浪分钟K（quotes.sina.cn/cn/api/json_v2.php/CN_MarketDataService.getKLineData）
   字段为 day/open/high/low/close/volume/amount，datalen 最大 1023；
   旧域名 money.finance.sina.com.cn 已返回 "Service not valid"。
6. A股 60 分钟K每日 4 根（9:30-10:30/10:30-11:30/13:00-14:00/14:00-15:00）。

用法:
    python fetch_kline.py --symbols hs300,kc50 --klt 101 --start 20240901 --end 20261024 --outdir ./data
    python fetch_kline.py --symbols hs300 --klt 60 --outdir ./data      # 自动降级源
    python fetch_kline.py --symbols hs300 --fflow --outdir ./data
"""
import argparse
import json
import os
import time
import urllib.request

# 代码映射: 名称 -> (东财secid, 腾讯代码, 新浪代码)
SYMBOLS = {
    "hs300": ("1.000300", "sh000300", "sh000300"),
    "kc50": ("1.000688", "sh000688", "sh000688"),
    "zz500": ("1.000905", "sh000905", "sh000905"),
    "zz1000": ("1.000852", "sh000852", "sh000852"),
    "cyb": ("0.399006", "sz399006", "sz399006"),
    "510300": ("1.510300", "sh510300", None),
    "510330": ("1.510330", "sh510330", None),
    "510310": ("1.510310", "sh510310", None),
    "159919": ("0.159919", "sz159919", None),
}

EM_KLINE = "https://push2his.eastmoney.com/api/qt/stock/kline/get"
EM_FFLOW = "https://push2his.eastmoney.com/api/qt/stock/fflow/daykline/get"
TC_FQKLINE = "https://ifzq.gtimg.cn/appstock/app/fqkline/get"
TC_MKLINE = "https://ifzq.gtimg.cn/appstock/app/kline/mkline"
SINA_KLINE = "https://quotes.sina.cn/cn/api/json_v2.php/CN_MarketDataService.getKLineData"

KLINE_FIELDS = "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61"


def _get(url, timeout=40, retries=3):
    """带重试的 GET，失败返回 None。数据源存在分钟级抖动/限流，重试间隔指数退避。"""
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read().decode("utf-8", "ignore")
        except Exception:
            if i == retries - 1:
                return None
            time.sleep(1.5 * (i + 1))
    return None


def _postprocess_em(text):
    """东财 kline JSON -> {date, open, close, high, low, volume, amount, pct} 列表。"""
    j = json.loads(text)
    rows = []
    for k in j["data"]["klines"]:
        p = k.split(",")
        rows.append({"date": p[0], "open": float(p[1]), "close": float(p[2]),
                     "high": float(p[3]), "low": float(p[4]), "volume": float(p[5]),
                     "amount": float(p[6]) if len(p) > 6 and p[6] else None,
                     "pct": float(p[8]) if len(p) > 8 and p[8] else None})
    return rows


def get_daily_em(secid, start, end):
    url = ("%s?secid=%s&fields1=f1,f2,f3,f4,f5,f6&fields2=%s&klt=101&fqt=1&beg=%s&end=%s"
           % (EM_KLINE, secid, KLINE_FIELDS, start, end))
    t = _get(url)
    if not t:
        return None
    try:
        return _postprocess_em(t)
    except Exception:
        return None


def get_daily_tc(code, start, end, limit=800):
    # 腾讯 fqkline 要求日期带连字符（2025-01-01），与东财的 20250101 不同
    s = "%s-%s-%s" % (start[:4], start[4:6], start[6:8]) if len(start) == 8 else start
    e = "%s-%s-%s" % (end[:4], end[4:6], end[6:8]) if len(end) == 8 else end
    url = ("%s?param=%s,day,%s,%s,%d,qfq" % (TC_FQKLINE, code, s, e, limit))
    t = _get(url)
    if not t:
        return None
    try:
        j = json.loads(t)
        k = list(j["data"].values())[0]
        rows = [{"date": r[0], "open": float(r[1]), "close": float(r[2]),
                 "high": float(r[3]), "low": float(r[4]), "volume": float(r[5])}
                for r in k.get("qfqday", k.get("day", []))]
        return rows
    except Exception:
        return None


def get_minute_tc(code, scale, limit=800):
    url = "%s?param=%s,m%d,,%d" % (TC_MKLINE, code, scale, limit)
    t = _get(url)
    if not t:
        return None
    try:
        j = json.loads(t)
        k = list(j["data"].values())[0]
        rows = [{"dt": r[0], "open": float(r[1]), "close": float(r[2]),
                 "high": float(r[3]), "low": float(r[4]), "volume": float(r[5])}
                for r in k.get("m%d" % scale, [])]
        return rows
    except Exception:
        return None


def get_minute_sina(code, scale, datalen=1023):
    url = "%s?symbol=%s&scale=%d&ma=no&datalen=%d" % (SINA_KLINE, code, scale, datalen)
    t = _get(url)
    if not t:
        return None
    try:
        rows = [{"dt": r["day"], "open": float(r["open"]), "high": float(r["high"]),
                 "low": float(r["low"]), "close": float(r["close"]),
                 "volume": float(r["volume"]), "amount": float(r.get("amount", 0))}
                for r in json.loads(t)]
        return rows
    except Exception:
        return None


def get_fflow_em(secid):
    """指数/个股资金流（仅最近约120个交易日）。字段见 references/data-sources.md。"""
    url = ("%s?secid=%s&lmt=0&klt=101&fields1=f1,f2,f3,f7"
           "&fields2=f51,f52,f53,f54,f55,f56,f57,f58" % (EM_FFLOW, secid))
    t = _get(url)
    if not t:
        return None
    try:
        j = json.loads(t)
        return [{"date": p[0], "main": float(p[1]), "small": float(p[2]),
                 "mid": float(p[3]), "large": float(p[4]), "xlarge": float(p[5]),
                 "main_pct": float(p[6])}
                for p in (k.split(",") for k in j["data"]["klines"])]
    except Exception:
        return None


def _to_klines(rows):
    """统一输出为东财 klines 字符串格式: date,open,close,high,low,volume[,amount[,pct]]。"""
    out = []
    for r in rows:
        dt = r.get("date") or r.get("dt")
        amt = r.get("amount")
        pct = r.get("pct")
        out.append("%s,%s,%s,%s,%s,%s,%s,%s" % (
            dt, r["open"], r["close"], r["high"], r["low"], r["volume"],
            "" if amt is None else amt,
            "" if pct is None else pct))
    return out


def fetch(symbol, klt, start, end, outdir, fflow=False):
    secid, tc, sina = SYMBOLS[symbol]
    os.makedirs(outdir, exist_ok=True)
    got = None
    src = None
    if klt == 101:
        got = get_daily_em(secid, start, end)
        src = "eastmoney"
        if not got:
            got = get_daily_tc(tc, start, end)
            src = "tencent"
    elif klt in (5, 15, 30, 60):
        if sina and klt == 60:                       # 新浪优先覆盖60分钟（含amount）
            got = get_minute_sina(sina, klt)
            src = "sina"
        if not got:
            got = get_minute_tc(tc, klt)
            src = "tencent"
        if not got and klt == 60:
            got = get_minute_em(secid)               # 最后尝试东财
            src = "eastmoney"
    if not got:
        print("  [FAIL] %s klt=%d 所有数据源失败" % (symbol, klt))
        return False
    fname = os.path.join(outdir, "%s_k%d.json" % (symbol, klt))
    with open(fname, "w", encoding="utf-8") as f:
        json.dump({"symbol": symbol, "klt": klt, "source": src,
                   "data": {"klines": _to_klines(got)}}, f)
    print("  [OK] %s klt=%d <- %s: %d 根 (%s ~ %s)"
          % (symbol, klt, src, len(got), got[0].get("date") or got[0].get("dt"),
             got[-1].get("date") or got[-1].get("dt")))
    return True


def get_minute_em(secid):
    url = ("%s?secid=%s&ut=7eea3edcaed734bea9cbfc24409ed989"
           "&fields1=f1,f2,f3,f4,f5,f6,f7,f8&fields2=%s&klt=60&fqt=1&end=20500101&lmt=1500"
           % (EM_KLINE, secid, KLINE_FIELDS))
    t = _get(url)
    if not t:
        return None
    try:
        j = json.loads(t)
        return [{"dt": p[0] + ":00", "open": float(p[1]), "close": float(p[2]),
                 "high": float(p[3]), "low": float(p[4]), "volume": float(p[5])}
                for p in (k.split(",") for k in j["data"]["klines"])]
    except Exception:
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbols", required=True, help="逗号分隔，支持 hs300/kc50/zz500/zz1000/cyb/510300/510330/510310/159919")
    ap.add_argument("--klt", type=int, default=101, help="101=日K, 60/30/15/5=分钟K")
    ap.add_argument("--start", default="20240901")
    ap.add_argument("--end", default="20500101")
    ap.add_argument("--fflow", action="store_true", help="同时获取资金流（仅东财，约120日）")
    ap.add_argument("--outdir", default="./data")
    args = ap.parse_args()
    for sym in args.symbols.split(","):
        sym = sym.strip()
        if sym not in SYMBOLS:
            print("  [SKIP] 未知代码 %s" % sym)
            continue
        fetch(sym, args.klt, args.start, args.end, args.outdir)
        if args.fflow:
            ff = get_fflow_em(SYMBOLS[sym][0])
            if ff:
                with open(os.path.join(args.outdir, "%s_fflow.json" % sym), "w", encoding="utf-8") as f:
                    json.dump({"symbol": sym, "data": {"klines": [
                        "%s,%s,%s,%s,%s,%s,%s" % (r["date"], r["main"], r["small"], r["mid"],
                                                  r["large"], r["xlarge"], r["main_pct"])
                        for r in ff]}}, f)
                print("  [OK] %s fflow: %d 日 (%s ~ %s)" % (sym, len(ff), ff[0]["date"], ff[-1]["date"]))
            else:
                print("  [WARN] %s fflow 失败（仅东财提供，无备选源；稍后重试或换网络）" % sym)


if __name__ == "__main__":
    main()
