# a-share-tech-indicators

A股指数/ETF/个股技术指标分析与数据获取 skill（用户级，agent_created）。

## 文件清单

```
a-share-tech-indicators/
├── SKILL.md                          # 技能说明（触发场景/工作流/已证结论）
├── README.md                         # 本文件（变更记录）
├── scripts/
│   ├── fetch_kline.py                # 多源容错数据获取（东财/腾讯/新浪）
│   ├── indicators.py                 # 纯因果指标计算 compute_all
│   └── judge.py                      # 规则A 三维投票 / 规则B 多因子评分
└── references/
    └── data-sources.md               # 接口清单/字段/单位陷阱/故障处置
```

## 变更记录

### v1.0（2026-10-24）
- 初版。从「沪深300×科创50 近一年技术指标分析」项目（outputs/）沉淀。
- fetch_kline.py：东财日K主源 + 腾讯 fqkline/mkline + 新浪分钟K 备选；统一输出
  东财 klines 字符串格式。已修复：腾讯日期格式需连字符；东财分钟接口 000 时
  自动降级；重试 3 次指数退避。
- indicators.py / judge.py：与项目版一致（无路径依赖，可直接 import）。
- 端到端验证：东财故障时自动降腾讯成功拉取 hs300/kc50/4只ETF/5分钟线；
  pit_backtest 用腾讯源复现东财源结果（-6.32% vs -10.88% 完全一致）。

## 同步说明

`indicators.py` / `judge.py` 在 pit-backtest skill 有同源副本（skill 需自包含）。
修改任一处时必须同步另一处，并在两边 README 记录。
