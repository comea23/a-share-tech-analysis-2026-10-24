# A股数据源接口清单与陷阱

## 一、数据源总览

| 源 | 域名 | 支持 | 稳定性 |
|---|---|---|---|
| 东财 push2his | push2his.eastmoney.com | 日K、分钟K、资金流(fflow) | 日K 间歇性 000；分钟K 常被拦 |
| 腾讯 ifzq | ifzq.gtimg.cn | 日K(fqkline)、分钟K(mkline) | 较稳；注意域名无 `web` 前缀 |
| 新浪 quotes | quotes.sina.cn | 5/15/30/60 分钟K | 较稳；仅分钟 |

## 二、接口详情

### 1. 东财日K（主源）
```
GET https://push2his.eastmoney.com/api/qt/stock/kline/get
    ?secid=1.000300&fields1=f1,f2,f3,f4,f5,f6
    &fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61
    &klt=101&fqt=1&beg=20240901&end=20261024
```
- secid：沪市 `1.` 前缀，深市 `0.` 前缀（如 159919 → `0.159919`）
- 日期格式：`20240901`（无连字符）
- 返回 `data.klines`：字符串数组 `date,open,close,high,low,volume,amount,amplitude,pct,turnover,...`

### 2. 东财资金流（fflow，仅约120个交易日）
```
GET https://push2his.eastmoney.com/api/qt/stock/fflow/daykline/get
    ?secid=1.000300&lmt=0&klt=101&fields1=f1,f2,f3,f7
    &fields2=f51,f52,f53,f54,f55,f56,f57,f58
```
- 返回 `date,主力,小单,中单,大单,超大单,主力净占比,收盘`（单位：元）
- **beg 参数无效，只返回最近约 120 个交易日**
- 无备选源，失败只能重试或换网络

### 3. 腾讯日K（备选）
```
GET https://ifzq.gtimg.cn/appstock/app/fqkline/get
    ?param=sh000300,day,2024-09-01,2026-10-24,800,qfq
```
- **日期必须带连字符**（与东财相反）
- 返回 `data.<code>.qfqday`：数组 `[date, open, close, high, low, volume]`（注意 close 在第三个）
- 无 amount/pct 字段，pct 需本地用收盘价差分补齐

### 4. 腾讯分钟K（备选）
```
GET https://ifzq.gtimg.cn/appstock/app/kline/mkline?param=sh510300,m5,,800
```
- 返回 `data.<code>.m5`：`[dt, open, close, high, low, volume]`，dt 形如 `202609231055`
- `web.ifzq.gtimg.cn` 域名会 301 跳 stgw 网关失败，**必须用 `ifzq.gtimg.cn`**

### 5. 新浪分钟K（备选，60分钟优先）
```
GET https://quotes.sina.cn/cn/api/json_v2.php/CN_MarketDataService.getKLineData
    ?symbol=sh000300&scale=60&ma=no&datalen=1023
```
- scale ∈ {5,15,30,60}；datalen 最大 1023
- 返回 JSON 数组：`day, open, high, low, close, volume, amount`
- 旧域名 `money.finance.sina.com.cn` 已返回 "Service not valid"，勿用

## 三、单位与口径陷阱

| 项 | 口径 |
|---|---|
| volume | **手**（1手=100股）。成交额 = volume × 100 × close。指数（hs300等）volume 单位为股，不乘 |
| 东财 amount | 元（日K） |
| A股 60分钟K | 每日 4 根（9:30-10:30 / 10:30-11:30 / 13:00-14:00 / 14:00-15:00） |
| 5分钟K | 每日 48 根；尾盘 30 分钟 = 14:30 后 6 根 |
| 复权 | 腾讯 qfq=前复权；跨源对比时注意复权口径一致 |

## 四、故障处置

| 现象 | 处置 |
|---|---|
| 东财 API 返回 HTTP 000（连接重置，root 却 404） | 该域名对当前网络不稳定，直接降级腾讯/新浪；不要反复重试或换节点（33/50/90 等节点同样失败） |
| 腾讯 fqkline 返回空/code≠0 | 检查日期是否带连字符；datalen 上限 800 |
| 全部源失败 | 网络级故障；间隔几分钟整体重试 |
| fflow 拉取失败 | 无备选源；分析脚本可降级跳过资金流维度 |

## 五、已支持代码映射

| 名称 | 东财 secid | 腾讯 | 新浪 |
|---|---|---|---|
| hs300 沪深300 | 1.000300 | sh000300 | sh000300 |
| kc50 科创50 | 1.000688 | sh000688 | sh000688 |
| zz500 中证500 | 1.000905 | sh000905 | sh000905 |
| zz1000 中证1000 | 1.000852 | sh000852 | sh000852 |
| cyb 创业板指 | 0.399006 | sz399006 | sz399006 |
| 510300 华泰柏瑞300ETF | 1.510300 | sh510300 | — |
| 510330 华夏300ETF | 1.510330 | sh510330 | — |
| 510310 易方达300ETF | 1.510310 | sh510310 | — |
| 159919 嘉实300ETF | 0.159919 | sz159919 | — |
