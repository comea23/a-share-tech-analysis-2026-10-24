# national-team-flow

国家队资金行为分析（沪深300方向）skill（用户级，agent_created）。

## 文件清单

```
national-team-flow/
├── SKILL.md                          # 技能说明（诚信声明/代理指标/判型规则）
├── README.md                         # 本文件（变更记录）
├── scripts/
│   ├── national_team.py              # 行为判型主引擎
│   └── build_national_report.py      # HTML 报告生成
└── references/
    └── proxy-indicators.md           # 代理指标详解/阈值依据/案例/歧义
```

## 变更记录

### v1.0（2026-10-24）
- 初版。从「国家队资金行为分析」项目（outputs/）沉淀。
- 相对项目版的修复：
  1. load 函数统一读 fetch_kline 输出格式（东财 klines 字符串）
  2. 腾讯源无 pct 字段 → 本地收盘价差分补齐
  3. **iloc 位置索引跨表错位 bug** → 改按标签 .loc[T] 取数（原 etf_tab 与 hs300
     表起点不一致时静默取错行，10-23 成交额 404 亿 vs 实际 301 亿）
  4. fflow 文件缺失时自动降级（跳过资金流维度）不中断
  5. DATA_DIR 环境变量支持
- 端到端验证：fflow 缺失下降级跑通 416 日；修复后 10-15 成交额/量比/判型
  与项目版一致（277.4 亿 / 4.31x / 买入托底特征明显）。

## 数据依赖

- hs300_k101.json（指数日K，必需）
- 510300/510330/510310/159919_k101.json（ETF 日K，必需）
- 510300_k5.json（五分钟线，尾盘维度用，缺失则尾盘列留空）
- hs300_fflow.json（资金流，可缺，缺失时跳过该维度）
